<template>
  <div class="full">
    <PhysicsRoom class="full"></PhysicsRoom>
  </div>
</template>

<script>
import { O3DVue } from '../../Core/O3DVue'
export default {
  mixins: [
    O3DVue
  ]
}
</script>

<style>

</style>